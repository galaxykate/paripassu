https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API

https://developer.mozilla.org/en-US/docs/Web/API/WebXR_Device_API/Spatial_tracking


A-Frame wants you to add JS to components, like Vue does
on "tick"