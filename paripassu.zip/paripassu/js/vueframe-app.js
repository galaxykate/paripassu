/*
 Apps are made out of a header (title/controls) and footer
 and some number of columns
 If its vertical, the columns can become sections in one column
 */

/*
	When events happen in the widgets, post them to Io?
	Or should every widget have access to the event log?
	"Something happened here, please send this to everyone"
*/

// Get query parameters
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());
const FRAME_RATE = 10
// Don't warn about "unknown" AFrame elements
Vue.config.ignoredElements = [/^a-/];

let room = new Room(params["room"] || "test");

window.onload = (event) => {
	// Create a room


	const app = new Vue({
		template: `
		<div id="app">
		<header></header>

			<!-- VR SCENE -->
			<a-scene v-if="!urlParams.aframe">
				<a-assets>
    			<img id="my-texture" src="img/textures/sky-day.png">
  			</a-assets>
				<a-entity :position="startingPos.toAFrame()">
					<a-entity id="camera" position="0 1.4 0" camera camera-watcher look-controls></a-entity>
				</a-entity>
				
				<vr-user  v-for="user in room.users" :user="user"  />
				
			
				<a-plane position="0 0 0" rotation="-90 0 0" width="40" height="40" color="#7BC8A4"></a-plane>
				<a-sky material="src: #my-texture"></a-sky>
			</a-scene>

			<!-- OVERLAY -->
			<div id="main-columns" style="position:absolute">
				<div class="main-column">
					<user-table :users="room.users" />
				</div>
				
			</div>
		
		<footer></footer>
		</div>`,

		data() {
			return {
				startingPos: new Vector(Math.random()*5 - 2.5, 0, Math.random()*5 - 2.5),
				urlParams: params,
				room: room,
			};
		},

		computed: {
			boxAnimation() {
				// return "property: position; to: 1 8 -10; dur: 500; easing: easeInOutQuad; loop: true; dir:alternate"
			},
			cameraPos() {
				if (this.room.user.head) {
					console.log("HEAD", this.room.user.head);
					let pos = this.room.user.head.position.toAFrame();
					return pos;
				}
				return "0 4 0";
				// room.user.head.rotation.toAFrame()
			},
		},
		methods: {},

		props: [],

		mounted() {
			
		},

		el: "#app",
	});
};
