/*
	Room
	A "place" with many users
*/

class Room {
	constructor(roomID) {
		this.authID = undefined
		this.currentRoomID = roomID
		
		// Create our "self"
		this.user = new User({
			room: this,
			isSelf: true,
			userdata: {
				displayName: localStorage.getItem("displayName") || words.getUserName()
			}
		})
		this.users = {}
		this.exists = false
		this.metadata = {}
		this.events = {}

		// // Create some fake users
		// for (var i = 0; i < 4; i++) {
		// 	let u = new User(this)
		// 	u.connectRef("FAKE_" + words.getRandomSeed(4))
		// }

	}

	//===========================================
	// Handle continuous motion
	// Keep this user (and all users in this room)
	

	//===========================================
	// Constructing sublists
	
	
	// Treat "messages" like any property "console.log(room.messages)"
	// Access but not set, computed on the fly
	get messages() {
		return this.getEventsByType("chat")
	}

	

	get currentScores() {
		// Sum up all point events
		let events = this.getEventsByType("point")
		
		let scores = {
		
		}

		events.forEach(ev => {
			let userID = ev.data.to
			let count = ev.data.count
			
			// If not in our table yet, set to 0
			if (scores[userID] == undefined)
				scores[userID] = 0

			scores[userID] += count
		})


		return scores
	}
	
	getEventsByType(type) {
		return Object.entries(this.events)
			.map(ev => {
				ev[1].id = ev[0]
				return ev[1]
			})
			.filter(ev => ev.type == type)
	}
	
	
	//===========================================
	// Events
	
	postEvent(event) {
		event.from = this.user.id
		event.time = Date.now()
		console.log(`${this} posts an event:`, event)
	
		// this.ref is the ROOM's reference
		// Create a new entry in this list
		
		// let newEventRef = this.eventRef.push();
		// newEventRef.set(event);
		// console.log("Set successfully?")
	}



	//===========================================
	// Setup

	setRoomID() {
		// Change the room ID. No problem if we haven't connected, 
		// Serious change if we have
	}

	joinRoom(roomID) {
		this.roomID = roomID
		console.log(`Joining room '${this.roomID}' as '${this.authID.slice(-4)}'`)
		

		this.users = {}
		this.events = []

		// Room data, does not change
		this.ref = this.databaseRef.ref(`rooms/${this.roomID}`)
		this.ref.get().then(snapshot => {
			if (snapshot.exists()) {
				const data = snapshot.val()
				console.log(`${this} exists`, data)

				// Copy over the data
				Object.assign(this.metadata,data.meta)

				// Handle existing users
				if (data.userStatus)
					for (const [uid, userdata] of Object.entries(data.userStatus)) {
						// Create an empty user for each user status
						new User({
							room:this,
							userdata: userdata
						})
	 				}

	 			// Copy over existing events
				if (data.events)
					for (const [evid, event] of Object.entries(data.events)) {
						Vue.set(this.events, evid, event)
					}
					

			} else {
				console.log(`${this} does not exist`)
				// Create this room
				this.ref.set({
					meta: {
						createdBy: this.authID,
						createdOn: Date.now()
					}
				})
			}
		})

		// User data like movement that changes constantly
		this.movementRef = this.databaseRef.ref(`rooms/${this.roomID}/movement`)
		
		// User status that changes on rarely
		this.userStatusRef = this.databaseRef.ref(`rooms/${this.roomID}/userStatus`)
		
		// Events, only added to, happens a few times per second
		this.eventRef = this.databaseRef.ref(`rooms/${this.roomID}/events`)

		console.log("add user to this room", this.user)
		this.userStatusRef.update({
			[this.authID]: this.user.toStatus()
		})

	}

	disconnectFromFirebase() {
		console.warn("TODO: disconnectFromFirebase")
	}

	// What room is this?
	connectToFirebase({databaseRef, authID, userData}) {
		console.log(`Connected as authID '${authID}'`)
		this.authID = authID
		this.databaseRef = databaseRef
		
		// Ok, that's us!
		// What room are we in?
		if (this.currentRoomID)
			this.joinRoom(this.currentRoomID)
		else
			console.warn("No room ID")
	
	}


	initializeFromServer(data) {
		console.log(`Initialize ${this} from server data`, data)
	}

	handleNewUser(userData, id) {
		// A user has changed status?

		// Do we have this user?
		if (this.users[id] == undefined) {
			// Is it us (use our existing user) or someone else?
			let user = this.authID === id?this.user:new User(this)
		
			// user.connectRef(id, userData)
		} 
	}


	
	handleNewEvent(ev, id) {
		if (this.events[id] === undefined) {
			// Add to my list of events
			ev.id = id
			Vue.set(this.events, id, ev)
		}
	}

	initFirebaseConnection(database) {
		console.log(`${this}: Initialized firebase connection`)
		this.database = database


	}

	toString() {
		return `Room '${this.roomID}'`
	}
}