/*
 * Components in AFrame and Vue
 */

AFRAME.registerComponent("camera-watcher", {
	schema: {}, // System schema. Parses into `this.data`.
	tick: function () {

		// Get the camera's current rotation
		var rotation = this.el.getAttribute("rotation");

		// Get the world position of the camera
		// It's on a rig, so this gets the position relative to the rig
		var worldPos = new THREE.Vector3();
		worldPos.setFromMatrixPosition(this.el.object3D.matrixWorld);
		room.user.setHeadPosition(worldPos, rotation);
	},
});

Vue.component("vr-user", {
	template: `
		<a-entity>
			<a-box :color="user.getColor(-.3)" :position="user.footPosition" depth=".15" :height="user.height*1.6" width=".35"></a-box>
			<a-entity :position="user.headPosition" :rotation="user.headRotation"  v-if="!user.isSelf">
				<a-box :color="user.getColor()" position="0 0 .05" :depth="user.headSize" :height="user.headSize" :width="user.headSize"></a-box>
				<a-box :color="user.getColor(-.2)" position="0 0 -.1" :depth="user.headSize*.5" :height="user.headSize*.3" :width="user.headSize*.2"></a-box>
			</a-entity>
			
		</a-entity>
	`,

	props: ["user"],
});
