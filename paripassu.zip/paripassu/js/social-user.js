
// // basicColors = ["#ff66ff", "#6699ff", "#3399ff", "#33ccff", "#66ffcc", "#66ff66", "#ccff66", "#ffcc66", "#ff9966", "#ff6699", "#ff66cc"]
// const basicColors = ["magenta", "cyan", "blue", "orange", "green", "salmon", "grey", "white", "lime", "pink", "purple", "tomato"]

class User {

	// Create a user
	constructor({room, userData, isSelf}) {
		this.room = room
		this.statusRef = undefined
		this.posRef = undefined
		this.id = undefined


		// Set some default values for this user
		this.status = {
			connected: false,
			idNumber: Math.floor(Math.random()*10000),
			color: new Vector(Math.random()*360, 100, 50),
			displayName: words.getUserName()
		}

		// Copy over userdata

		Object.assign(this.status, userData)
		
		

		// The user may or may not have a body
		this.controllers = undefined
		this.head = undefined

		console.log(`Created user ${this}`)

		
	}

	toStatus() {
		let s = {}
		for (const [key, val] of Object.entries(this.status)) {
			s[key] = val
			if (val instanceof Vector)
				s[key] = val.toArray()
		}
		return s			
	}

	//-------------------------------
	// Positions

	setHeadPosition(pos, rot) {
		
		// Issue: if this is an Euler, we want 
		this.head.position.setTo(pos.x, pos.y, pos.z)
		this.head.rotation.setTo(rot.x, rot.y, rot.z)
		
		this.pushToServer(true)
		
	}

	get headPosition() {
		return this.head.position.toAFrame()
	}

	get headRotation() {
		return this.head.rotation.toAFrame()
	}

	get footPosition() {
		let v = this.head.position.clone()
		v.v[1] = 0
		// if (this.isSelf) {
		// 	console.log("Foot:",  v.toAFrame(), this.head.position.toAFrame())
		// }
		return v.toAFrame()
		// return ""
	}

	get height() {
		return this.head.position.v[1]
	}

	//-------------------------------
	// Color

	getColor(shade, fade) {
		return this.color.toHex(shade, fade)
	}

	toString() {
		let s = `${this.status.displayName}`
		if (this.isSelf)
			s += "*"

		if (s.id !== undefined) {
			s += `(${this.id.slice(-4)})`
		}
			s += `(offline)`
			

		return s
	}


	connectRef(id, userData) {
		// We have a FB ID and some userdata

		// Register us on the room's list o' users
		Vue.set(this.room.users, id, this)

		console.log(`Setting id for ${this.displayName} to ${id}`, this.room.authID)
		this.id = id

		// // If we have a reference, subscribe to changes to this object
		// // *our* reference in the Realtime Database
		// // Keep the status and position in different places
		this.posRef = this.room.userRef.child(this.id)
		this.statusRef = this.room.userStatusRef.child(this.id)

		
		if (this.isSelf) {
			// Keep track of the user's status
			// For handling:
			// - status: if people have disconnected
			
			this.statusRef.onDisconnect().update({
				connected: false,
				time: Date.now()
			})

			this.statusRef.set({
				connected: true,
				time: Date.now()
			})

		}

		// // Get initial snapshot
		// this.posRef.get().then((snapshot) => {
		// 	// Do I have any starting values?
		// 	// Use them, but keep anything we don't have 
		// 	//  on the server yet (for new features)
		// 	if (snapshot.exists()) 
		// 		this.fromData(snapshot.val())

		// 	// Create a push to the server in case we have new stuff
		// 	this.pushToServer()

		// 	// Ignore server data about yourself
		// 	// You are the best source of truth on that, right?
		// 	if (!this.isSelf) {
		// 		this.posRef.on('value', (snapshot) => {
					
		// 			if (snapshot.exists()) {
		// 				// Tell me whenever this user's data changes
		// 				// console.log(`${this} value changed!!`)
		// 				this.fromData(snapshot.val())
		// 			} else {
		// 				this.destroy()
		// 			}
				
		// 		});
		// 	}

			
		// })
	
		
		return this
	}


	get isSelf() {
		return this.room.user === this
	}

	get headData() {
		return {
			head: {
				position:this.head.position.toArray(),
				rotation:this.head.rotation.toArray()
			}
		}
	}
	get postableData() {
		return {
			connected: true,
			time: Date.now(),
			color: this.color.toArray(),
			displayName: this.displayName,
			head: {
				position:this.head.position.toArray(),
				rotation:this.head.rotation.toArray()
			}
		}
	}

	destroy() {
		console.log(`${this} DESTROYED!!`)
		Vue.delete(this.room.users, this.id)
		this.statusRef.remove()
		this.posRef.remove()
	}


	pushToServer(justHead) {
		let t = Date.now()
		if (this.lastPosPush === undefined || t - this.lastPosPush > 1000/FRAME_RATE) {
			if (this.ref) {
				// Push this user's position to the server (only if it's us)
				if (justHead) {
					this.posRef.update(this.headData)
				}
				else
					this.posRef.update(this.postableData)
			}
			this.lastPosPush = t
		}
	}

	fromData(data) {
		let staticKeys = ["displayName", "connected"]
		let vectorKeys = ["color"]
		staticKeys.forEach(key => {
			// console.log(key, "server val", data[key], "current val", this[key])
			if (data[key] !== undefined)
				Vue.set(this, key, data[key])
		})
		vectorKeys.forEach(key => {
			// console.log(`\t${this} ${key}:`, "server val", data[key], "current val", this[key])
			if (data[key] !== undefined)
				this[key].setTo(data[key])
		})

		let headKeys = ["position", "rotation"]
		headKeys.forEach(key => {
			// console.log(`\t${this} ${key}:`, "server val", data[key], "current val", this[key])
			if (data.head && data.head[key] !== undefined)
				this.head[key].setTo(data.head[key])
		})
	}

}
