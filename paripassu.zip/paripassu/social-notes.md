Using Firebase 8 so we don't have to use it module-style ()

Security:
it is OK to reveal the Firebase settings! They are visible on your page!
Is it ok to have no rules?

# Database
https://firebase.google.com/docs/database/web/start


Enable authentication on Firebase


-----------------
5/9

Put it on Glitch ✅

Basic game loop
Goal: create some set of prompts, get answers, vote on best